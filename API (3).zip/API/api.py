import datetime, json
from flask import Flask, abort, request
from flask import jsonify

app = Flask(_name_)

tasks = [
    {
        "id": 1,
        "name": "Tomar la clase",
        "check": False,
        "created": datetime.datetime.now().time(),
        "updated": None,

    },
    {
        "id": 2,
        "name": "Hacer la tarea",
        "check": False,
        "created": datetime.datetime.now().time(),
        "updated": None,
    },
]


"""@app.route("/")
def hello_world():
    return "Hello, World!"""




@app.route('/api/tasks/', methods=["GET"])
def get_tasks():
    return jsonify({"tasks": tasks})


@app.route('/api/tasks/<int:id>', methods=["GET"])
def get_task(id):
    this_task = [task for task in tasks if task["id"] == id]
    return (
        jsonify({"task": this_task[0]})
        if this_task
        else jsonify({"status": "ID Inexistente"})
    )


@app.route('/api/tasks/', methods=["POST"])
def create_task():
    if not request.json:
        abort(404)
    task = {
        "id": len(tasks) + 1,
        "name": request.json["name"],
        "check": False,
        "creado": datetime.datetime.now().time(),
    }
    tasks.append(task)
    return jsonify({"tasks": tasks}), 201


@app.route('/api/tasks/<int:task_id>', methods=["PUT"])
def update_task(task_id):
    if not request.json:
        abort(400)

    this_task = [task for task in tasks if task["id"] == task_id]

    if not this_task:
        abort(404)

    if "name" in request.json and type(request.json.get("name")) is not str:
        abort(400)

    if "check" in request.json and type(request.json.get("check")) is not bool:
        abort(400)

    this_task[0]["name"] = request.json.get("name", this_task[0]["name"])
    this_task[0]["check"] = request.json.get("check", this_task[0]["check"])

    this_task[0].update({"modify": datetime.datetime.now().time()})

    return jsonify({"task": this_task[0]}), 201


@app.route('/api/tasks/<int:task_id>', methods=["DELETE"])
def delete_task(task_id):
    this_task = [task for task in tasks if task["id"] == task_id]

    if not this_task:
        abort(404)

    tasks.remove(this_task[0])
    return jsonify({"result": True})


with open("json_data.json", "s") :
    json.dump(tasks, indent=4, sort_keys=True, default=str)

